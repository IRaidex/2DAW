CREATE TABLE `alimentos` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `nombre` varchar(255) NOT NULL,
 `energia` decimal(10,0) NOT NULL,
 `proteina` decimal(10,0) NOT NULL,
 `hidratocarbono` decimal(10,0) NOT NULL,
 `fibra` decimal(10,0) NOT NULL,
 `grasatotal` decimal(10,0) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;