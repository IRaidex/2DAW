<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
    </head>
    <body>
        <?php
          
            $primera="alex";
            $segunda=123;
            $tercera=13.96;
            $cuarta=true;
        
            echo gettype($primera)."<br>";
            echo gettype($segunda)."<br>";
            echo gettype($tercera)."<br>";
            echo gettype($cuarta)."<br>";
        
        ?>
    </body>
</html>