<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
    </head>
    <body>
        <?php
            echo "<ul>";
            echo "<li>1</li>";
            echo "<li>2</li>";
            echo "<li>3</li>";
            echo "<li>4</li>";
            echo "<li>5</li>";
            echo "<li>6</li>";
            echo "<li>7</li>";
            echo "<li>8</li>";
            echo "<li>9</li>";
            echo "<li>10</li>";
            echo "</ul>";
        ?>
    </body>
</html>