<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
    </head>
    <body>
        <?php
          
            echo hola();
        
            function hola(){
                echo "Hola Mundo";
            }
        
        ?>
    </body>
</html>