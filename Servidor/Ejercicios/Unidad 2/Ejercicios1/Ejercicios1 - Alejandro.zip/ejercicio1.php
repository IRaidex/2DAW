<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php
   echo "Nombre: Alejandro<br>";
   echo "Apellidos: Salcedo Santamaria<br>";
   echo "Email: alejandrosal1396@gmail.com <br>";
   echo "Foto: <img src='halcon.png' alt='foto'><br>";
    ?>
</body>
</html>