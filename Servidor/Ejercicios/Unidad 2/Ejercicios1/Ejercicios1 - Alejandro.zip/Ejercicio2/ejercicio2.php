<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Curriculum</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link href="https://fonts.googleapis.com/css?family=Barlow&display=swap" rel="stylesheet">
        <title>Portafolio</title>
    </head>
    <body>
        <?php
        require_once "cabecera.php";
        ?>
        <img  src="foto.JPG" alt="retrato" >
        <section>
            <ul>
                <li><span>Nombre: </span>Alejandro</li>
                <li><span>Apellidos: </span>Salcedo Santamaria</li>
                <li><span>Fecha de nacimiento: </span>13/02/1996</li>
                <li><span>Nacionalidad: </span>Español</li>
                <li><span>Estado civil: </span>Soltero</li>
                <li><span>Ocupacion: </span>Estudiante</li>
            </ul>
        </section>
    </body>
</html>