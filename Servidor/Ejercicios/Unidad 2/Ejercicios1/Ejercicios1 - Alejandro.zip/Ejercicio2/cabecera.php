<?php
echo '<header><p>El Portafolio</p></header>
        <nav>
            <ul class="nav1">
                <li class="nav2"><a class="active" href="presentacion.html">Presentacion</a></li>
                <li class="nav2"><a href="trabajos.html">Trabajos</a></li>
                <li class="nav2"><a href="hobbies.html">Hobbies</a></li>
                <li class="nav2"><a class="active" href="curriculum.html">Curriculum</a></li>
            </ul>
        </nav>';
?>