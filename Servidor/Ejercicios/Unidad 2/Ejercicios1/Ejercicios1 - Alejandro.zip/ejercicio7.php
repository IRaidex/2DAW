<?php

include_once ("funciones.inc_Sandra.php");

$num1=6;
$num2=4;

echo operaciones($num1,$num2)."<br>";

?>